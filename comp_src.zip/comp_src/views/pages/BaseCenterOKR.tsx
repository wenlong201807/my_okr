import React from "react";


const BaseCenterOKR = () => {


    return (
        <div className="editorCellCla">
            <span>中心基线</span>
        </div>
    );
};

export default BaseCenterOKR;
